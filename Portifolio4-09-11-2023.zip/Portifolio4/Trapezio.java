package Portifolio4;

import java.lang.Math;

public class Trapezio implements FiguraGeometrica {
    private int baseMaior;
    private int baseMenor;
    private int altura;

    public int getBaseMaior() {
        return baseMaior;
    }

    public void setBaseMaior(int baseMaior) {
        try {
            if (baseMaior <= 0) {
                throw new IllegalArgumentException("A base maior deve ser maior que zero.");
            }
            this.baseMaior = baseMaior;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public int getBaseMenor() {
        return baseMenor;
    }

    public void setBaseMenor(int baseMenor) {
        try {
            if (baseMenor <= 0) {
                throw new IllegalArgumentException("A base menor deve ser maior que zero.");
            }
            this.baseMenor = baseMenor;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        try {
            if (altura <= 0) {
                throw new IllegalArgumentException("A altura deve ser maior que zero.");
            }
            this.altura = altura;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    @Override
    public double getArea() {
        int area = 0;
        area = ((baseMaior + baseMenor) * altura) / 2;
        return area;
    }

    @Override
    public double getPerimetro() {
        double perimetro = 0;
        double a = 0;
        double b = altura;
        double c = (baseMaior - baseMenor) / 2;
        double soma;
        soma = (b * b) + (c * c);
        a = Math.sqrt(soma);

        perimetro = baseMaior + baseMenor + (a * 2);

        return perimetro;
    }

    @Override
    public String getNomeFigura() {
        return "Trapezio";
    }
}
