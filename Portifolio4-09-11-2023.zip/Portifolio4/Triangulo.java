package Portifolio4;

public class Triangulo implements FiguraGeometrica {
    private int base;
    private int altura;
    private int ladoA;
    private int ladoB;
    private int ladoC;

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        try {
            if (altura <= 0) {
                throw new IllegalArgumentException("A altura deve ser maior que zero.");
            }
            this.altura = altura;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        try {
            if (base <= 0) {
                throw new IllegalArgumentException("A base deve ser maior que zero.");
            }
            this.base = base;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public int getLadoA() {
        return ladoA;
    }

    public void setLadoA(int ladoA) {
        try {
            if (ladoA <= 0) {
                throw new IllegalArgumentException("O ladoA deve ser maior que zero.");
            }
            this.ladoA = ladoA;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public int getLadoB() {
        return ladoB;
    }

    public void setLadoB(int ladoB) {
        try {
            if (ladoB <= 0) {
                throw new IllegalArgumentException("O ladoB deve ser maior que zero.");
            }
            this.ladoB = ladoB;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public int getLadoC() {
        return ladoC;
    }

    public void setLadoC(int ladoC) {
        try {
            if (ladoC <= 0) {
                throw new IllegalArgumentException("O ladoC deve ser maior que zero.");
            }
            this.ladoC = ladoC;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public String verificar_lado() {
        if (ladoA > ladoB + ladoC) {
            System.out.println("ERRO: o lado A é maior que a soma do lado B e C");
        }
        if (ladoB > ladoA + ladoC) {
            System.out.println("ERRO: o lado B é maior que a soma do lado A e C");
        }
        if (ladoC > ladoB + ladoA) {
            System.out.println("ERRO: o lado C é maior que a soma do lado B e A");
        }
        return null;
    }

    @Override
    public String getNomeFigura() {
        return "Interface1.Triangulo";
    }

    @Override
    public double getArea() {
        int area = 0;
        area = (base * altura) / 2;
        return area;
    }

    @Override
    public double getPerimetro() {
        int perimetro = 0;
        perimetro = ladoA + ladoB + ladoC;
        return perimetro;
    }
}