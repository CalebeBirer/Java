package Portifolio4;

public interface FiguraGeometrica {
    public String getNomeFigura();
    public double getArea();
    public double getPerimetro();

}
