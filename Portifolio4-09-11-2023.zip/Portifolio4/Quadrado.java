package Portifolio4;

public class Quadrado implements FiguraGeometrica {
    private int lado;

    public int getLado(){
        return lado;
    }

    public void setLado(int lado){
        try {
            if (lado <= 0) {
                throw new IllegalArgumentException("O lado deve ser maior que zero.");
            }
            this.lado = lado;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    @Override
    public double getArea() {
        int area = 0;
        area = lado * lado;
        return area;
    }
    @Override
    public double getPerimetro(){
        int perimetro = 0;

        perimetro = lado * 4;
        return perimetro;
    }
    @Override
    public String getNomeFigura(){
        return "quadrado";
    }

}