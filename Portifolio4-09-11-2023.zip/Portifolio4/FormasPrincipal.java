package Portifolio4;

public class FormasPrincipal {
    public static void main(String[] args) {
        double a;
        String b;

        Quadrado q2 = new Quadrado();
        Triangulo g3 = new Triangulo();
        Circulo c4 = new Circulo();
        Trapezio t5 = new Trapezio();

        q2.setLado(4);
        a = q2.getArea();
        System.out.println("A area do quadrado é de: " + a);
        a = q2.getPerimetro();
        System.out.println("O perimetro do quadrado é de: " + a);
        b = q2.getNomeFigura();
        System.out.println("Nome da figura: " + b);
        System.out.println("---------------------------------------");

        g3.setLadoA(3);
        g3.setLadoB(3);
        g3.setLadoC(2);
        g3.setAltura(5);
        g3.setBase(8);
        String verificar = g3.verificar_lado();
        a = g3.getArea();
        System.out.println("A area do triangulo é de: " + a);
        a = g3.getPerimetro();
        System.out.println("O perimetro do triangulo é de: " + a);
        b = g3.getNomeFigura();
        System.out.println("Nome da figura: " + b);
        System.out.println("---------------------------------------");

        c4.setRaio(1);
        c4.setCircunferencia(1);
        a = c4.getArea();
        System.out.println("A area do circulo é de: " + a);
        a = c4.getPerimetro();
        System.out.println("O perimetro do circulo é de: " + a);
        b = c4.getNomeFigura();
        System.out.println("Nome da figura: " + b);
        System.out.println("---------------------------------------");

        t5.setBaseMaior(2);
        t5.setBaseMenor(3);
        t5.setAltura(1);
        a = t5.getArea();
        System.out.println("A area do trapezio é de: " + a);
        a = t5.getPerimetro();
        System.out.println("O perimetro do trapezio é de: " + a);
        b = t5.getNomeFigura();
        System.out.println("Nome da figura: " + b);
        System.out.println("---------------------------------------");

    }
}