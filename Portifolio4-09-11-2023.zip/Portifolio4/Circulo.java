package Portifolio4;


import java.lang.Math;

public class Circulo implements FiguraGeometrica {

    private double raio;
    private double circunferencia;
    private double pi = Math.PI;

    public double getRaio() {
        return raio;
    }

    public void setRaio(double raio) {
        try {
            if (raio <= 0) {
                throw new IllegalArgumentException("O raio deve ser maior que zero.");

            }
            this.raio = raio;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    public double getCircunferencia() {
        return circunferencia;
    }

    public void setCircunferencia(double circunferencia) {
        try {
            if (circunferencia <= 0) {
                throw new IllegalArgumentException("A circunferencia deve ser maior que zero.");

            }
            this.circunferencia = circunferencia;
        } catch (IllegalArgumentException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

    @Override
    public double getArea() {
        double area = 0;
        area = pi * (raio * raio);
        return area;
    }

    @Override
    public double getPerimetro() {
        double perimetro = 0;
        perimetro = 2 * pi * raio;
        return perimetro;
    }

    @Override
    public String getNomeFigura() {
        return "Circulo";
    }
}
